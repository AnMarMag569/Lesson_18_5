from django.shortcuts import render
from django.views.generic import TemplateView


# Create your views here.
class Platform_view(TemplateView):
    template_name = 'fourth_task/platform.html'


def games_view(request):
    games = {
        'games': ["ВИТАМИНЫ", "МИНЕРАЛЫ", "ДОБАВКИ"]
    }
    return render(request, 'fourth_task/games.html', context=games)


class Cart_view(TemplateView):
    template_name = 'fourth_task/cart.html'




# Create your views here.
