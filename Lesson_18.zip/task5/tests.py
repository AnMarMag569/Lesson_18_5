from django.test import TestCase

# Create your tests here.
if request.method == 'POST':
    username = request.POST.get('username')
    password = request.POST.get('password')
    repeat_password = request.POST.get('repeat_password')
    age = request.POST.get('age')

    if username in users:
        info['username'] = 'Пользователь уже существует'
    elif len(password) < 8:
        info['password'] = 'Пароль должен быть не менее 8 символов'
    elif password != repeat_password:
        info['repeat_password'] = 'Пароли не совпадают'
    elif int(age) < 18:
        info['age'] = 'Вы должны быть старше 18'
    else:
        info['message'] = f'Приветствуем, {username}!'
    print(info)